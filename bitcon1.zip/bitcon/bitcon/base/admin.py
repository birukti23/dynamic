from django.contrib import admin

from .models import AboutSection
admin.site.register(AboutSection)


from .models import Home_Section
admin.site.register(Home_Section)


from .models import Service
admin.site.register(Service)


from .models import ContactSubmission
admin.site.register(ContactSubmission)



from .models import Feature
admin.site.register(Feature)


from .models import TokenSale
admin.site.register(TokenSale)


from .models import FAQ
admin.site.register(FAQ)



